# tic-tac-toe-project
# My Lovely Game
# was veryyyyyyy great experince :)

List technologies used:
-Animate.min.css.
-Responsive design.
-Flex.
-jQuery.
-call-back function.
-sweetalert.min.js.
-Audio.


User Stories:
-User is able to start a new tic tac toe game by clicking on Restart button.
-User is able to start a new tic tac toe game.
-User is shown a message after each turn for if I win, lose, tie.
-User can't click the same square twice.
-User can't continue playing once win, lose, or tie.
-User is able to play the game again without refreshing the page.


Extra Tic Tac Toe Features are included :
-Players are allowed to customize their token whether they would like to start as X or as O ,instead of just making X is always go first.
-The site is fully responsive .
-Hover effects and animations are both used.
-Audio is used.
-Calculate the scores .
-LocalStorage working even after the page is refresh. 
